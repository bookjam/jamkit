include("tuubcast.js");

function follow() {
    var singer = $data["group"] ? $data["group"] + "." + $data["member"] : $data["member"];
    var url = $BASEURL + "/follow";
    
    fetch(url, {
        method: "POST",
        body: JSON.stringify({
            singer: singer,
            gender: "boy",
            video_id: $data["video-id"]
        }),
        headers:session_headers()
    }, true);
    
    __send_event_to_analytics("App-Click", "follow", singer + "-" + $data["video-id"]);
}

function unfollow() {
    var singer = $data["group"] ? $data["group"] + "." + $data["member"] : $data["member"];
    var url = $BASEURL + "/unfollow";
    
    fetch(url, {
        method: "POST",
        body: JSON.stringify({
            singer: singer,
            gender: "boy",
            video_id: $data["video-id"]
        }),
        headers:session_headers()
    }, true);
    
    __send_event_to_analytics("App-Click", "unfollow", singer + "-" + $data["video-id"]);
}

function __send_event_to_analytics(category, action, label, value) {
    var event = "category=" + category + ","
                "action="   + action   + ","
                "label="    + label;
    
    if (value) {
        event = event + "," + "value=" + value;
    }
    
    controller.action("analytics", { event:event });
}
