var baseurl = "http://jamkit-1378.appspot.com/api/v1/com.tuubcast.tuubcastfancam";

if ($env["SANDBOX"] == "yes") {
    baseurl = "http://jamkit-test-147402.appspot.com/api/v1/com.tuubcast.tuubcastfancam";
}

var current_singer  = null;
var hearts_of_today = -1;
var hearts_to_add   = 0;
var hearts_to_send  = 0;

var ranking_board_visible_count = 0;
var hearts_sending_count = 0;

function update_hearts_and_ranking() {
    var singer = __current_singer();

    if (typeof(singer) !== "undefined") {
        __update_hearts_and_ranking(singer);
    }
}

function __update_hearts_and_ranking(singer) {
    var url = baseurl + "/singers?gender=boy&singer=" + singer;

    fetch(url, null, true).then(function(response) {
    	if (response.ok) {
    		response.json().then(function(data) {
        		if (singer === current_singer) {
                    var hearts_count = data.today.hearts_count + hearts_to_add;
                
            		if (hearts_of_today == -1) {
                		hearts_of_today = hearts_count;
            		}

                    __update_today_hearts_label(hearts_of_today);
                    __update_today_ranking_label(data.today.ranking);
                    __update_ranking_up_label(data.singer, data.today.ranking);

                    var next_rank = data.today.next_rank;

                    if (next_rank) {
                        __update_ranking_down_label(next_rank.singer, next_rank.ranking);
                    }

                    __update_ranking_cell(data);

            		hearts_to_add = 0;
        		}
    		});
    	} else {
            if (response.status == 417) {
                controller.action("subview", { subview:"V_HOME" });
                controller.action("reset-app");
            }
        }
        
        __wait_done_hearts_today_label();
        __wait_done_today_ranking_label();
    });
    
    current_singer  = singer;
    hearts_of_today = -1;
    hearts_to_add   = 0;
    
    __wait_hearts_today_label();
    __wait_today_ranking_label();
}

function send_10hearts() {
    if (controller.status("network") == "offline") {
        controller.action("alert", { message:"네트워크 연결이 필요합니다." });
        
        return;
    }

    controller.points("O_0000_000000044", 10, true, function(total_amount) {
        if (total_amount == -1) {
            controller.action("toast", { message:"포인트 충전이 필요합니다." });
                      
            return;
        }

  	    __send_hearts(__current_singer(), 10);

        controller.action("toast", { message:"10하트를 보냈습니다." });
    });
}

function send_1heart() {
    if (controller.status("network") == "offline") {
        controller.action("alert", { message:"네트워크 연결이 필요합니다." });
        
        return;
    }

    controller.points("O_0000_000000044", 1, true, function(total_amount) {
        if (total_amount == -1) {
            controller.action("toast", { message:"포인트 충전이 필요합니다." });
                      
            return;
        }
         
   	    __send_hearts(__current_singer(), 1);

   	    controller.action("toast", { message:"1하트를 보냈습니다." });
    });
}

function __send_hearts(singer, amount) {
    if (hearts_to_send == 0) {
        timeout(0.3, function() {
            var url = baseurl + "/hearts";
            var current_ranking = __current_today_ranking();

            fetch(url, {
                method: "POST",
                body: JSON.stringify({
                    singer: singer,
                    gender: "boy",
                    value: hearts_to_send,
                    video_id:__current_video_id()
                }),
                headers:__session_headers()
            }, true).then(function(response) {
                if (response.ok) {
                    response.json().then(function(data) {
                        if (singer === current_singer) {
                            var hearts_count = data.today.hearts_count;

                            if (hearts_sending_count == 1) {
                                data.response.forEach(function(points) {
                                    __update_points(points.points_id, points.points_info);
                                });

                                hearts_of_today = hearts_count;
                            }

                            if (hearts_of_today != -1) {
                                __update_today_hearts_label(hearts_of_today);
                            }

                            __update_today_ranking_label(data.today.ranking);
                            __update_ranking_up_label(data.singer, data.today.ranking);

                            var next_rank = data.today.next_rank;

                            if (next_rank) {
                                __update_ranking_down_label(next_rank.singer, next_rank.ranking);
                            }

                            if (data.today.ranking < current_ranking) {
                                __blink_ranking_board_section();
                            }
                        }
                    });
                } else {
                    if (response.status == 417) {
                        controller.action("subview", { subview:"V_HOME" });
                        controller.action("reset-app");
                    }
                }

                hearts_sending_count--;
            });

            hearts_sending_count++;
            hearts_to_send = 0;
        });
    }

    hearts_to_send = hearts_to_send + amount;

    if (hearts_of_today != -1) {
        var hearts_count = hearts_of_today + amount;
        
        __update_today_hearts_label(hearts_count);
        __boom_today_hearts_label();

        hearts_of_today = hearts_count;
    } else {
        hearts_to_add = hearts_to_add + amount;
    }
}

/* helper functions */

function __current_singer() {
    var data = controller.object("cell.ranking.today").data("display-unit");

    if (typeof(data) !== "undefined") {
        return data.group ? data.group + "." + data.member : data.member;
	}	

	/* undefined */
}

function __current_video_id() {
    var data = controller.object("cell.ranking.today").data("display-unit");
    
    if (typeof(data) !== "undefined") {
        return data["video-id"];
    }
    
    /* undefined */
}

function __current_today_ranking() {
    var value = controller.object("ranking.today").value();
    
    if (typeof(value) !== "undefined") {
        return parseInt(value);
    }
    
    /* undefined */
}

function __update_ranking_cell(singer) {
	var cell = controller.object("cell.ranking");
    var fluctuation_value = (singer.fluctuation !== "new") 
    					  ? singer.fluctuation_value.toString() : ""; 

	cell.data("display-unit", {
    	"ranking":singer.ranking.toString(),
    	"fluctuation":singer.fluctuation,
    	"fluctuation-value":fluctuation_value,
    	"hearts-count":singer.hearts_count.toString()
    });
	cell.action("reload");
}

function __wait_hearts_today_label() {
	var label = controller.object("hearts.today");
    
    label.action("wait");
}

function __wait_done_hearts_today_label() {
    var label = controller.object("hearts.today");
    
    label.action("wait-done");
}

function __update_today_hearts_label(count) {
    var label = controller.object("hearts.today");
    
    label.action("property", { properties:"text=" + count.toString() });
}

function __boom_today_hearts_label() {
    var label = controller.object("hearts.today");

    label.action("property", { properties:"scale=2.0" });
    timeout(0.15, function() {
        label.action("property", { properties:"scale=1.0" });
    });
}

function __wait_today_ranking_label() {
    var label = controller.object("ranking.today");
    
    label.action("wait");
}

function __wait_done_today_ranking_label() {
    var label = controller.object("ranking.today");
    
    label.action("wait-done");
}

function __update_today_ranking_label(ranking) {
    var label = controller.object("ranking.today");
    
    label.action("property", { properties:"text=" + ranking.toString() });
}

function __update_ranking_up_label(singer, ranking) {
    var checkbox = controller.object("ranking.up");
    var label = ranking.toString() + "위  " + singer;
    
    checkbox.action("property", { properties:"label=" + label });
}

function __update_ranking_down_label(singer, ranking) {
    var checkbox = controller.object("ranking.down");
    var label = ranking.toString() + "위  " + singer;
    
    checkbox.action("property", { properties:"label=" + label });
}

function __blink_ranking_board_section() {
    __show_ranking_board_section();
    
    timeout(3.0, function() {
        if (ranking_board_visible_count == 1) {
            __hide_ranking_board_section();
        }

        ranking_board_visible_count--;
    });

    ranking_board_visible_count++;
}

function __show_ranking_board_section() {
    var section = controller.object("ranking.board");

    section.action("show");    
}

function __hide_ranking_board_section() {
    var section = controller.object("ranking.board");

    section.action("hide");    
}

function __update_points(points_id, points_info) {
    controller.action("invoice", {
        "invoice-type":"points",
        "points":points_id,
        "total-amount":points_info.total_amount.toString(),
        "amount":points_info.amount.toString(),
        "shows-throbber":"no"
    });
}

function __session_headers() {
    return {
        "User-Key":storage.value("UserKey")
    }
}
