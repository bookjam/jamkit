var baseurl = "http://jamkit-1378.appspot.com/api/v1/com.tuubcast.tuubcastfancam";

if ($env["SANDBOX"] == "yes") {
    baseurl = "http://jamkit-test-147402.appspot.com/api/v1/com.tuubcast.tuubcastfancam";
}

function update() {
    __update_code();
    __update_count();
}

function copy() {
    var code = storage.value("RecommendCode");

    if (typeof(code) !== "undefined") {
        var text = "아이돌 직캠 큐레이션 앱, 튭캐스트#직캠\n\n" +
                   "추천인 코드: " + code + "\n" +
                   "앱 설치 주소: " + "http://bit.ly/2hCrp9k";

        controller.action("copy", { media:"text", text:text } );
    } else {
        var message = "추천인 코드가 발행되지 않았습니다."
                      "잠시 후 다시 시도하시거나 앱을 재실행해주세요.";
        
        controller.action("alert", { message:message });
    }
}

function __update_code() {
    var code = storage.value("RecommendCode");
    
    if (typeof(code) !== "undefined") {
        __update_code_label(code);
    } else {
        __wait_code_label();
    }
}

function __update_code_label(code) {
    var label = controller.object("code");
    
    label.action("property", {"properties":"text=" + code});
}

function __wait_code_label() {
    var label = controller.object("code");
    
    label.action("wait");
}

function __wait_done_code_label() {
    var label = controller.object("code");
    
    label.action("wait-done");
}

function __update_count() {
    var url = baseurl + "/user";
    
    fetch(url, {
    	headers:__session_headers()
    }, true).then(function(response) {
    	if (response.ok) {
    		response.json().then(function(data) {
                __update_count_label(data.recommend_count);
                __wait_done_count_label();
            });
    	}
    });
    
    __wait_count_label();
}

function __update_count_label(count) {
    var label = controller.object("count");
    
    label.action("property", {"properties":"text=" + count.toString()});
}

function __wait_count_label() {
    var label = controller.object("count");
    
    label.action("wait");
}

function __wait_done_count_label() {
    var label = controller.object("count");
    
    label.action("wait-done");
}

function __session_headers() {
    return {
        "User-Key":storage.value("UserKey")
    }
}

