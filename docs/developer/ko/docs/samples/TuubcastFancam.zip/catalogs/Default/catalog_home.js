include("tuubcast.js");

var do_not_show_restore_button = false;

function update() {
    var user_code = storage.value("UserCode");

    if (typeof(user_code) === "undefined") {
        if (!do_not_show_restore_button) {
            __show_restore_button();
        }
    }
}

function girls() {
    var user_code = storage.value("UserCode");

    if (typeof(user_code) === "undefined") {
        controller.action("freeze", { message:"시작하는 중..." });

        __signup("V_GIRLS");

        return;
    }

    controller.action("subview", { subview:"V_GIRLS" });
    controller.action("reload", { target:"object", subview:"V_GIRLS", object:"showcase.main" });
}

function boys() {
    var user_code = storage.value("UserCode");

    if (typeof(user_code) === "undefined") {
        controller.action("freeze", { message:"시작하는 중..." });

        __signup("V_BOYS");

        return;
    }

    controller.action("subview", { subview:"V_BOYS" });
    controller.action("reload", { target:"object", subview:"V_BOYS", object:"showcase.main" });
}

function on_restore() {
    __hide_restore_button();

    do_not_show_restore_button = true;
}

function __show_restore_button() {
    var button = controller.object("restore");
    
    button.action("show");
}

function __hide_restore_button() {
    var button = controller.object("restore");
    
    button.action("hide");
}

function __signup(subview) {
    var url = $BASEURL + "/user/signup";
    
    fetch(url, {
        method: "POST",
    }, true).then(function(response) {  
        if (response.ok) {
            response.json().then(function(data) {
                storage.value("UserCode", data.user_code);
                storage.value("UserKey", data.user_key);
                storage.value("RecommendCode", data.recommend_id);
                storage.value("RecommendDone", data.recommend_done ? "yes" : "no");
                storage.synchronize();

                if (response.status != 208) {
                    controller.action("toast", { message:"최초 설치 100하트가 지급되었습니다!" });
                }

                controller.action("subview", { subview:subview });
                 controller.action("reload", { target:"object", subview:subview, object:"showcase.main" });
               controller.action("unfreeze");
                                 
                controller.points("O_0000_000000044", function(points) {
                    __request_daily_points();
                });
                                 
                __hide_restore_button();
            });
        } else {
            controller.action("alert", { message:"문제가 발생했습니다. 잠시 후 다시 시도해주세요.", error:response.status });
            controller.action("unfreeze");
        }
    });
}

function __request_daily_points() {
    var url = $BASEURL + "/points/daily";
    
    fetch(url, {
        method: "POST",
        headers:session_headers()
    }, true).then(function(response) {  
        if (response.ok) {
            response.json().then(function(data) {
                var amount = 0;
                
                data.response.points.forEach(function(points) {
                    if (points.points_id === "O_0000_000000044") {
                        amount = amount + points.points_info.amount;
                    }
                    
                    __update_points(points.points_id, points.points_info);
                });

                if (amount > 0) {
                    controller.action("toast", { message:"출석 감사 " + amount.toString() + "하트가 지급되었습니다." });
                }
            });
        }   
    }); 
}

function __update_points(points_id, points_info) {
    controller.action("invoice", {
        "invoice-type":"points",
        "points":points_id,
        "total-amount":points_info.total_amount.toString(),
        "amount":points_info.amount.toString(),
        "shows-throbber":"no"
    });
}
