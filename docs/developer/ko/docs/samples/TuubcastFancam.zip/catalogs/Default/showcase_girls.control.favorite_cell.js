var baseurl = "http://jamkit-1378.appspot.com/api/v1/com.tuubcast.tuubcastfancam";

if ($env["SANDBOX"] == "yes") {
    baseurl = "http://jamkit-test-147402.appspot.com/api/v1/com.tuubcast.tuubcastfancam";
}

function follow() {
    var singer = $data["group"] ? $data["group"] + "." + $data["member"] : $data["member"];
    var url = baseurl + "/follow";
    
    fetch(url, {
        method: "POST",
        body: JSON.stringify({
            singer: singer,
            gender: "girl",
            video_id: $data["video-id"]
        })
    }, true);

    __send_event_to_analytics("App-Click", "follow", singer + "-" + $data["video-id"]);
}

function unfollow() {
    var singer = $data["group"] ? $data["group"] + "." + $data["member"] : $data["member"];
    var url = baseurl + "/unfollow";
    
    fetch(url, {
        method: "POST",
        body: JSON.stringify({
            singer: singer,
            gender: "girl",
            video_id: $data["video-id"]
        })
    }, true);

    __send_event_to_analytics("App-Click", "unfollow", singer + "-" + $data["video-id"]);
}

function __send_event_to_analytics(category, action, label, value) {
    var event = "category=" + category + ","
                "action="   + action   + ","
                "label="    + label;
    
    if (value) {
        event = event + "," + "value=" + value;
    }
    
    controller.action("analytics", { event:event });
}
