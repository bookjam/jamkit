var baseurl = "http://jamkit-1378.appspot.com/api/v1/com.tuubcast.tuubcastfancam";

if ($env["SANDBOX"] == "yes") {
    baseurl = "http://jamkit-test-147402.appspot.com/api/v1/com.tuubcast.tuubcastfancam";
}

function feed(keyword, location, length, sortkey, sortorder, callback) {
    var url = baseurl + "/singers/top30?gender=girl";

    fetch(url, null, true).then(function(response) {
    	if (response.ok) {
    		response.json().then(function(data) {
    			var list = [];

    			data.forEach(function(singer) {
    				var fluctuation_value = (singer.fluctuation !== "new")
    									  ? singer.fluctuation_value.toString() : "";

    				list.push({
    					"auxiliary":"S_GIRLS_MEMBERS_" + singer.singer,
    					"ranking":singer.ranking.toString(),
    					"fluctuation":singer.fluctuation,
    					"fluctuation-value":fluctuation_value,
    					"hearts-count":singer.hearts_count.toString()
    				});
    			});

    			if (data.length > 0) {
    				storage.value("TopGirl", data[0].singer);
    			}

    			callback(list);
    		});
    	}
    });
}
