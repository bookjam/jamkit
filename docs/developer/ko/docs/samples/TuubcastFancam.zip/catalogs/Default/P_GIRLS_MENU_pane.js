include("tuubcast.js");

function feed_daily(keyword, location, length, sortkey, sortorder, callback) {
    __feed("daily", callback);
}

function feed_weekly(keyword, location, length, sortkey, sortorder, callback) {
    __feed("weekly", callback);
}

function __feed(type, callback) {
    var url = $BASEURL + "/singers/top30?gender=girl";

    fetch(url, null, true).then(function(response) {
        if (response.ok) {
            response.json().then(function(data) {
                var list = [];

                data.forEach(function(singer) {
                    var fluctuation_value = (singer.fluctuation !== "new")
                                          ? singer.fluctuation_value.toString() : "";

                    list.push({
                        "auxiliary":"S_GIRLS_MEMBERS_" + singer.singer,
                        "ranking":singer.ranking.toString(),
                        "fluctuation":singer.fluctuation,
                        "fluctuation-value":fluctuation_value,
                        "hearts-count":singer.hearts_count.toString()
                    });
                });

                if (type === "daily" && data.length > 0) {
                    storage.value("TopGirl", data[0].singer);
                }

                callback(list);
            });
        }
    });
}
