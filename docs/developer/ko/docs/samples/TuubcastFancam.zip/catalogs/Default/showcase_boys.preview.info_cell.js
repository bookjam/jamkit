function update() {
    var top_singer = storage.value("TopBoy");
    
    if (top_singer && top_singer === __current_singer()) {
        __show_number_1_image();
    }
}

function __show_number_1_image() {
    var image = controller.object("1st");
    
    image.action("show");
}

function __current_singer() {
    return $data.auxiliary.substring("S_BOYS_MEMBERS_".length);
}
