var baseurl = "http://jamkit-1378.appspot.com/api/v1/com.tuubcast.tuubcastfancam";

if ($env["SANDBOX"] == "yes") {
    baseurl = "http://jamkit-test-147402.appspot.com/api/v1/com.tuubcast.tuubcastfancam";
}

function update() {
    var done = storage.value("RecommendDone");

    __update_code();

    if (typeof(done) === "undefined" || done !== "yes") {
        __show_recommend_button();
    }
}

function start_ad() {
    var url = baseurl + "/points/adlog";
    var button = controller.object("reward.ad");

    fetch(url, {
        method:"POST",
        body:JSON.stringify({ ad_id: button.value("ad"), step:"start" }),
        headers:__session_headers()
    }, true).then(function(response) {
        if (response.ok) {
            // do nothing
        }
    });
}

function finish_ad() {
    var url = baseurl + "/points/adlog";
    var button = controller.object("reward.ad");

    fetch(url, {
        method:"POST",
        body:JSON.stringify({ ad_id: button.value("ad"), step:"complete" }),
        headers:__session_headers()
    }, true).then(function(response) {
        if (response.ok) {
            // do nothing 
        }
    });
}

function __update_code() {
    var user_code = storage.value("UserCode");
    var label = controller.object("code");
    
    if (typeof(user_code) !== "undefined") {
        label.action("property", {"properties":"text=" + user_code});
    } else {
        label.action("wait");
    }
}

function __show_recommend_button() {
    var button = controller.object("recommend");
    
    button.action("show");
}

function __session_headers() {
    return {
        "User-Key":storage.value("UserKey")
    }
}
