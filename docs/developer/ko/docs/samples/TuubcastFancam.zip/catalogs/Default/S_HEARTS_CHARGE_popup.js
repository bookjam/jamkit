include("tuubcast.js");

var current_ad = null;

function update() {
    var done = storage.value("RecommendDone");

    __update_code();

    if (typeof(done) === "undefined" || done !== "yes") {
        __show_recommend_button();
    }
}

function start_ad() {
    current_ad = __next_ad(storage.value("LastAd"));

    controller.action("ad", { ad:current_ad });
    __log_ad(current_ad, "start");
    
    storage.value("LastAd", current_ad);
}

function finish_ad() {
    __log_ad(current_ad, "complete");
}

function __update_code() {
    var user_code = storage.value("UserCode");
    var label = controller.object("code");
    
    if (typeof(user_code) !== "undefined") {
        label.action("property", {"properties":"text=" + user_code});
    } else {
        label.action("wait");
    }
}

function __show_recommend_button() {
    var button = controller.object("recommend");
    
    button.action("show");
}

function __next_ad(last_ad) {
    if (last_ad === "A_0000_000000001") {
        return "A_0000_000000002";
    }

    if (last_ad === "A_0000_000000002") {
        return "A_0000_000000003";
    }

    return "A_0000_000000001";
}

function __log_ad(ad, step) {
    var url = $BASEURL + "/points/adlog";

    fetch(url, {
        method:"POST",
        body:JSON.stringify({ ad_id:ad, step:step }),
        headers:session_headers()
    }, true).then(function(response) {
        if (response.ok) {
            // do nothing 
        }
    });
}
