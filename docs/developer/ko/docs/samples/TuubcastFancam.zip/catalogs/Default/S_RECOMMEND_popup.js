var baseurl = "http://jamkit-1378.appspot.com/api/v1/com.tuubcast.tuubcastfancam";

if ($env["SANDBOX"] == "yes") {
    baseurl = "http://jamkit-test-147402.appspot.com/api/v1/com.tuubcast.tuubcastfancam";
}

function submit(data) {
	if (controller.status("network") == "offline") {
        controller.action("alert", { message:"네트워크 연결이 필요합니다." });
        
        return;
    }

    __submit(data);
}

function __submit(data) {
	var url = baseurl + "/user/recommend";

	fetch(url, {
		method: "POST",
        body: JSON.stringify({ recommend_id: data["code"] }),
        headers:__session_headers()
    }, true).then(function(response) {
    	if (response.ok) {
            response.json().then(function(data) {
    	        data.response.points.forEach(function(points) {
           			__update_points(points.points_id, points.points_info);
	            });

    	        storage.value("RecommendDone", "yes");

                controller.action("alert", { message:"추천 포인트가 지급되었습니다." });
                controller.action("popup-close");
            });
    	} else {
            var message = "추천인 등록에 실패했습니다.";
                
            if (response.status == 403) {
            	message = "추천인 코드가 잘못되었습니다.";
            }
            
    		controller.action("alert", { message:message, error:response.status.toString() });
    	}

        controller.action("unfreeze");
    }).catch(function(error){
   		controller.action("alert", { message:"추천인 등록에 실패했습니다." });
        controller.action("unfreeze");
    });

    controller.action("freeze", { message:"등록 중..." });
}

function __update_points(points_id, points_info) {
    controller.action("invoice", {
        "invoice-type":"points",
        "points":points_id,
        "total-amount":points_info.total_amount.toString(),
        "amount":points_info.amount.toString(),
        "shows-throbber":"no"
    });
}

function __session_headers() {
    return {
        "User-Key":storage.value("UserKey")
    }
}
