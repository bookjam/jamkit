include("tuubcast.js");

var last_rankings = null;

function update() {
	var singer = $data["group"] ? $data["group"] + "." + $data["member"] : $data["member"];
   	var url = $BASEURL + "/singers/detail?gender=girl&singer=" + singer;

    fetch(url, null, true).then(function(response) {
    	if (response.ok) {
    		response.json().then(function(data) {
    			__update_rankings(data);
     		});
    	}
    });
}

function goto_1st() {
    if (last_rankings) {
        var showcase = controller.object("showcase.main");
        
        showcase.action("category", { category:last_rankings[0].singer });
        controller.action("popup-close");
        controller.action("toast", { message:__member_name(last_rankings[0]) });
    }
}

function goto_upper_2() {
	if (last_rankings && last_rankings[1].singer) {
        var showcase = controller.object("showcase.main");
        
        showcase.action("category", { category:last_rankings[1].singer });
        controller.action("popup-close");
        controller.action("toast", { message:__member_name(last_rankings[1]) });
    }
}

function goto_upper_1() {
    if (last_rankings && last_rankings[2].singer) {
        var showcase = controller.object("showcase.main");
        
        showcase.action("category", { category:last_rankings[2].singer });
        controller.action("popup-close");
        controller.action("toast", { message:__member_name(last_rankings[2]) });
    }
}

function goto_lower_1() {
    if (last_rankings && last_rankings[4].singer) {
        var showcase = controller.object("showcase.main");
        
        showcase.action("category", { category:last_rankings[4].singer });
        controller.action("popup-close");
        controller.action("toast", { message:__member_name(last_rankings[4]) });
    }
}

function goto_lower_2() {
    if (last_rankings && last_rankings[5].singer) {
        var showcase = controller.object("showcase.main");
        
        showcase.action("category", { category:last_rankings[5].singer });
        controller.action("popup-close");
        controller.action("toast", { message:__member_name(last_rankings[5]) });
    }
}

function goto_singer() {
    if (last_rankings && last_rankings[3].singer) {
        var showcase = controller.object("showcase.main");
        
        controller.action("popup-close");
        controller.action("toast", { message:__member_name(last_rankings[3]) });
    }
}

function __update_rankings(rankings) {
    __update_1st_member_label(__member_name(rankings[0]));

    if (rankings[1].singer) {
    	__update_upper_2_ranking_label(rankings[1].ranking);
    	__update_upper_2_member_label(__member_name(rankings[1]));
    }

    if (rankings[2].singer) {
    	__update_upper_1_ranking_label(rankings[2].ranking);
    	__update_upper_1_member_label(__member_name(rankings[2]));
    }

    if (rankings[4].singer) {
    	__update_lower_1_ranking_label(rankings[4].ranking);
    	__update_lower_1_member_label(__member_name(rankings[4]));
    }

    if (rankings[5].singer) {
    	__update_lower_2_ranking_label(rankings[5].ranking);
    	__update_lower_2_member_label(__member_name(rankings[5]));
    }

    __update_singer_ranking_label(__member_name(rankings[3]), rankings[3].ranking);
    __update_singer_hearts_label(rankings[3].today_hearts_count);

    if (rankings[3].ranking != 1) {
    	__update_hearts_up_label(Math.max(rankings[2].hearts_count - rankings[3].hearts_count, 1));
    	__update_hearts_1st_label(Math.max(rankings[0].hearts_count - rankings[3].hearts_count, 1));
 
    	__show_non_1st_group();
    	__hide_1st_group();
    } else {
    	__show_1st_group();
    	__hide_non_1st_group();
    }

    last_rankings = rankings;
}

function __update_1st_member_label(member) {
	var label = controller.object("member.1st");

	label.action("property", { properties:"text=" + member });
}

function __update_upper_2_ranking_label(ranking) {
	var label = controller.object("ranking.upper.2");

	label.action("property", { properties:"text=" + ranking.toString() });
}

function __update_upper_2_member_label(member) {
	var label = controller.object("member.upper.2");

	label.action("property", { properties:"text=" + member });
}

function __update_upper_1_ranking_label(ranking) {
	var label = controller.object("ranking.upper.1");

	label.action("property", { properties:"text=" + ranking.toString() });
}

function __update_upper_1_member_label(member) {
	var label = controller.object("member.upper.1");

	label.action("property", { properties:"text=" + member });
}

function __update_lower_1_ranking_label(ranking) {
	var label = controller.object("ranking.lower.1");

	label.action("property", { properties:"text=" + ranking.toString() });
}

function __update_lower_1_member_label(member) {
	var label = controller.object("member.lower.1");

	label.action("property", { properties:"text=" + member });
}

function __update_lower_2_ranking_label(ranking) {
	var label = controller.object("ranking.lower.2");

	label.action("property", { properties:"text=" + ranking.toString() });
}

function __update_lower_2_member_label(member) {
	var label = controller.object("member.lower.2");

	label.action("property", { properties:"text=" + member });
}

function __update_singer_ranking_label(singer, ranking) {
    var checkbox = controller.object("ranking.singer");
    var label = ranking.toString() + "위  " + singer;
    
    checkbox.action("property", { properties:"label=" + label });
 	checkbox.action("show");
}

function __update_singer_hearts_label(count) {
	var label = controller.object("singer.hearts");
	var format = label.format("format");

	label.action("property", { properties:"text=" + format.replace("#_", count.toString()) });
	label.action("show");
}

function __update_hearts_up_label(count) {
	var label = controller.object("hearts.up");
	var format = label.format("format");

	label.action("property", { properties:"text=" + format.replace("#_", count.toString()) });
}

function __update_hearts_1st_label(count) {
	var label = controller.object("hearts.1st");
	var format = label.format("format");

	label.action("property", { properties:"text=" + format.replace("#_", count.toString()) });
}

function __show_1st_group() {
	controller.action("show", { group:"1st" });
}

function __hide_1st_group() {
	controller.action("hide", { group:"1st" });
}

function __show_non_1st_group() {
	controller.action("show", { group:"non.1st" });
}

function __hide_non_1st_group() {
	controller.action("hide", { group:"non.1st" });
}

function __member_name(ranking) {
	var singer = ranking.singer;
	var tokens = singer.split(/[\s\.]+/);

	if (tokens.length > 1) {
		var member = tokens[tokens.length - 1];
		var group = singer.substring(0, singer.length - member.length - 1);

		return group + " - " + member;
	}

	return singer;
}

