function update() {
    __update_proposition();
}

function __update_proposition() {
    var proposition = __proposition_for_name($data.member);
    var proposition_label = controller.object("postposition");

    proposition_label.action("property", { properties:"text=" + proposition });
}

function __proposition_for_name(name) {
    if (((name.charCodeAt(name.length - 1) - parseInt('0xAC00',16)) % 28) == 0) {
    	return "가";
    }

	return "이";
}
