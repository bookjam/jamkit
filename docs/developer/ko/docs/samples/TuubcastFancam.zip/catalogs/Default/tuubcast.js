var $BASEURL = "http://jamkit-1378.appspot.com/api/v1/com.tuubcast.tuubcastfancam";

if ($env["SANDBOX"] == "yes") {
    $BASEURL = "http://jamkit-test-147402.appspot.com/api/v1/com.tuubcast.tuubcastfancam";
}

function session_headers() {
    return {
        "User-Key":storage.value("UserKey")
    }
}
