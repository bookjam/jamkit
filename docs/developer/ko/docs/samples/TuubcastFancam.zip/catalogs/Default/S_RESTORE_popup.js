var baseurl = "http://jamkit-1378.appspot.com/api/v1/com.tuubcast.tuubcastfancam";

if ($env["SANDBOX"] == "yes") {
    baseurl = "http://jamkit-test-147402.appspot.com/api/v1/com.tuubcast.tuubcastfancam";
}

function submit(data) {
    if (controller.status("network") == "offline") {
        controller.action("alert", { message:"네트워크 연결이 필요합니다." });
        
        return;
    }
    
    __submit(data);
}

function __submit(data) {
	var url = baseurl + "/user/restore";

	fetch(url, {
		method: "POST",
        body: JSON.stringify({ user_code: data["code"] }),
        headers:__session_headers()
    }, true).then(function(response) {
    	if (response.ok) {
            response.json().then(function(data) {
                controller.action("popup-close");
                controller.action("reset-app", { "script-when-done":"on_restore" });

                controller.action("alert", { message:"사용자코드가 변경되었습니다." });
                controller.action("unfreeze");
            });
    	} else {
            var message = "사용자코드 변경에 실패했습니다.";
                
            if (response.status == 403) {
            	message = "사용자코드가 잘못되었습니다.";
            }
            
    		controller.action("alert", { message:message, error:response.status.toString() });
            controller.action("unfreeze");
    	}
    }).catch(function(error){
   		controller.action("alert", { message:"사용자코드 변경에 실패했습니다." });
        controller.action("unfreeze");
    });

    controller.action("freeze", { message:"등록 중..." });
}

function __session_headers() {
    return {
        "User-Key":storage.value("UserKey")
    }
}
