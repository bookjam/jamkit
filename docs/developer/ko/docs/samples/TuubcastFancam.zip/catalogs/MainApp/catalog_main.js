var baseurl = "http://jamkit-1378.appspot.com/api/v1/com.tuubcast.tuubcastfancam";

if ($env["SANDBOX"] == "yes") {
    baseurl = "http://jamkit-test-147402.appspot.com/api/v1/com.tuubcast.tuubcastfancam";
}

var first_appeared = true;

function loaded() {
    if (first_appeared) {
        __login();
        __update_top_girl();
        __update_top_boy();
    }
    
    first_appeared = true;
}

function foreground() {
    if (!first_appeared) {
        __login();
        __update_top_girl();
        __update_top_boy();
    }

    first_appeared = false;
}

function __login() {
    var url = baseurl + "/user/login";
  
    fetch(url, {
        method: "POST",
    }, true).then(function(response) {  
        var user_code = storage.value("UserCode");
    
        if (response.ok) {
            response.json().then(function(data) {
                if (typeof(user_code) !== "undefined" && user_code !== data.user_code) {
                    controller.action("subview", "V_HOME");
                    controller.action("reset-app");
                } else {
                    controller.points("O_0000_000000044", 0, true, function(total_amount) {
                        __request_daily_points();
                    });
                }
            });
        } else {
            if (typeof(user_code) !== "undefined") {
                controller.action("subview", { subview:"V_HOME" });
                controller.action("reset-app");
            }
        }
    });
}

function __request_daily_points() {
    var url = baseurl + "/points/daily";
    
    fetch(url, {
        method: "POST",
        headers:__session_headers()
    }, true).then(function(response) {  
        if (response.ok) {
            response.json().then(function(data) {
                var amount = 0;
                
                data.response.points.forEach(function(points) {
                    if (points.points_id === "O_0000_000000044") {
                        amount = amount + points.points_info.amount;
                    }
                    
                    __update_points(points.points_id, points.points_info);
                });

                if (amount > 0) {
                    controller.action("toast", { message:"출석 감사 " + amount.toString() + "하트가 지급되었습니다!" });
                }
            });
        }   
    }); 
}

function __update_top_girl() {
    var url = baseurl + "/singers/top30?gender=girl";

    fetch(url, null, true).then(function(response) {
        if (response.ok) {
            response.json().then(function(data) {
                if (data.length > 0) {
                    storage.value("TopGirl", data[0].singer);
                }
            });
        }
    });
}

function __update_top_boy() {
    var url = baseurl + "/singers/top30?gender=boy";

    fetch(url, null, true).then(function(response) {
        if (response.ok) {
            response.json().then(function(data) {
                if (data.length > 0) {
                    storage.value("TopBoy", data[0].singer);
                }
            });
        }
    });
}

function __update_points(points_id, points_info) {
    controller.action("invoice", {
        "invoice-type":"points",
        "points":points_id,
        "total-amount":points_info.total_amount.toString(),
        "amount":points_info.amount.toString(),
        "shows-throbber":"no"
    });
}

function __session_headers() {
    return {
        "User-Key":storage.value("UserKey")
    }
}
